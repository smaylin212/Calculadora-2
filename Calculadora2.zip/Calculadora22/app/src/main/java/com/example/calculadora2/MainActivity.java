package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText numero1;
    EditText numero2;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1 = (EditText) findViewById(R.id.numero1);
        numero2 = (EditText) findViewById(R.id.numero2);
        resultado = (TextView) findViewById(R.id.resultado);

    }
    public void Suma (View View) {
        double valor1 = Double.parseDouble(numero1.getText().toString());
        double valor2 = Double.parseDouble(numero2.getText().toString());
        double sumatotal = valor1 + valor2;
        resultado.setText(Double.toString(sumatotal));
    }

    public void Resta (View View) {
        double valor1=Double.parseDouble(numero1.getText().toString());
        double valor2=Double.parseDouble(numero2.getText().toString());
        double resttotal= valor1 - valor2;
        resultado.setText(Double.toString(resttotal));
        
    }
}